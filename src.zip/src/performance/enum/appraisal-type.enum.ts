export enum AppraisalType {
  ANNUAL = 'ANNUAL',
  PROBATION = 'PROBATION',
  MID_YEAR = 'MID_YEAR',
}