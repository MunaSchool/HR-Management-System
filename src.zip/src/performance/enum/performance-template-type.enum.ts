export enum PerformanceTemplateType {
  ANNUAL = 'ANNUAL',
  PROBATION = 'PROBATION',
  MID_YEAR = 'MID_YEAR',
}
