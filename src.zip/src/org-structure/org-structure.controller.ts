import { Controller } from '@nestjs/common';

@Controller('org-structure')
export class OrgStructureController {}
