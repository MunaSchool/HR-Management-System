import { Controller } from '@nestjs/common';

@Controller('employee-profile')
export class EmployeeProfileController {}
