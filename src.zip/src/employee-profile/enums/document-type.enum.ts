// src/employee-profile/enums/document-type.enum.ts

export enum DocumentType {
  ID = 'ID',
  PASSPORT = 'PASSPORT',
  CONTRACT = 'CONTRACT',
  CERTIFICATE = 'CERTIFICATE',
  CV = 'CV',
  OFFER_LETTER = 'OFFER_LETTER',
  ONBOARDING_FORM = 'ONBOARDING_FORM',
  MEDICAL_DOCUMENT = 'MEDICAL_DOCUMENT',
  WORK_AUTHORIZATION = 'WORK_AUTHORIZATION',
  OTHER = 'OTHER',
}
